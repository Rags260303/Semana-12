﻿using System;

namespace T12_RAGS_1255721
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
